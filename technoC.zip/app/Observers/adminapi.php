<?php

namespace App\Observers;

class adminapi
{
    //
}
